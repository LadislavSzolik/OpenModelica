# Set OpenModelica OMNotebook environment variables.
export DRMODELICAHOME=/usr/share/omnotebook/drmodelica/
